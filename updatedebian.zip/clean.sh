sudo apt clean
sudo apt -y autoclean
sudo apt -y autoremove
