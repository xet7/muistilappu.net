sudo apt -y install unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
sudo chown root:root 20auto-upgrades 50unattended-upgrades 
sudo mv 20auto-upgrades /etc/apt/apt.conf.d/
sudo mv 50unattended-upgrades /etc/apt/apt.conf.d/
