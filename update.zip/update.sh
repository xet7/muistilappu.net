sudo apt update
sudo apt -y dist-upgrade
sudo snap refresh
